/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rubric;

/**
 *
 * @author LENOVO
 */
public class Student {
    private String name;
    private String RegNo;
    private String Email;

    public String getName() {
        return name;
    }

    public String getRegNo() {
        return RegNo;
    }

    public String getEmail() {
        return Email;
    }

    public void setName(String name) {
        
        this.name = name;
    }

    public void setRegNo(String RegNo) {
        this.RegNo = RegNo;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }
    
    
    
    
}
